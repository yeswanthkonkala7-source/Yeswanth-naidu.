package com.renttech.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;

@Entity
@Table(name="products")
public class Product {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @NotBlank private String name;
 @NotBlank private String category;
 @NotBlank private String brand;
 @Positive private BigDecimal pricePerDay;
 private String imageUrl;
 private String description;
 private boolean available = true;

 public Product() {}
 public Product(String name,String category,String brand,BigDecimal pricePerDay,String imageUrl,String description){
  this.name=name;this.category=category;this.brand=brand;this.pricePerDay=pricePerDay;this.imageUrl=imageUrl;this.description=description;
 }
 public Long getId(){return id;} public String getName(){return name;} public void setName(String v){name=v;}
 public String getCategory(){return category;} public void setCategory(String v){category=v;}
 public String getBrand(){return brand;} public void setBrand(String v){brand=v;}
 public BigDecimal getPricePerDay(){return pricePerDay;} public void setPricePerDay(BigDecimal v){pricePerDay=v;}
 public String getImageUrl(){return imageUrl;} public void setImageUrl(String v){imageUrl=v;}
 public String getDescription(){return description;} public void setDescription(String v){description=v;}
 public boolean isAvailable(){return available;} public void setAvailable(boolean v){available=v;}
}
