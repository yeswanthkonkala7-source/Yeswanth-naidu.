package com.renttech.controller;
import com.renttech.model.*;
import com.renttech.repository.*;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.time.temporal.ChronoUnit;
import java.util.List;

@RestController
@RequestMapping("/api/rentals")
@CrossOrigin
public class RentalController {
 private final RentalRepository rentals; private final ProductRepository products;
 public RentalController(RentalRepository rentals,ProductRepository products){this.rentals=rentals;this.products=products;}

 @PostMapping public ResponseEntity<?> create(@Valid @RequestBody RentalRequest r){
  if(r.startDate()==null||r.endDate()==null||r.endDate().isBefore(r.startDate()))
   return ResponseEntity.badRequest().body("End date must be on or after start date.");
  Product p=products.findById(r.productId()).orElseThrow();
  if(!p.isAvailable()) return ResponseEntity.badRequest().body("Product is currently unavailable.");
  long days=ChronoUnit.DAYS.between(r.startDate(),r.endDate())+1;
  Rental x=new Rental();x.setCustomerName(r.customerName());x.setCustomerEmail(r.customerEmail());x.setPhone(r.phone());
  x.setProduct(p);x.setStartDate(r.startDate());x.setEndDate(r.endDate());x.setTotalPrice(p.getPricePerDay().multiply(BigDecimal.valueOf(days)));
  return ResponseEntity.ok(rentals.save(x));
 }
 @GetMapping public List<Rental> byEmail(@RequestParam String email){return rentals.findByCustomerEmailIgnoreCaseOrderByIdDesc(email);}
 public record RentalRequest(String customerName,String customerEmail,String phone,Long productId,java.time.LocalDate startDate,java.time.LocalDate endDate){}
}
