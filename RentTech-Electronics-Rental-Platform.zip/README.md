# RentTech — Electronics Rental Platform

A Java Spring Boot + PostgreSQL full-stack rental application for laptops, smartphones, tablets and cameras.

## Run locally

1. Install Java 17 and Maven.
2. Create PostgreSQL database `renttech`.
3. Default local credentials are `postgres` / `postgres`, or set:
   `DB_USERNAME` and `DB_PASSWORD`.
4. Run:
   `mvn spring-boot:run`
5. Open http://localhost:8080

## API

- GET `/api/products`
- GET `/api/products/{id}`
- POST `/api/products`
- PUT `/api/products/{id}`
- DELETE `/api/products/{id}`
- POST `/api/rentals`
- GET `/api/rentals?email=user@example.com`

## GitHub

```bash
git init
git add .
git commit -m "Initial RentTech application"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Render

The included `render.yaml` creates the web service and PostgreSQL database. Connect the GitHub repository to Render and deploy using the Blueprint configuration.

For production, add authentication, payment processing, image storage, admin authorization and stronger validation before accepting real customer data.
