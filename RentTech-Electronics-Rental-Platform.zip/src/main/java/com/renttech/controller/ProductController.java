package com.renttech.controller;
import com.renttech.model.Product;
import com.renttech.repository.ProductRepository;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin
public class ProductController {
 private final ProductRepository repo;
 public ProductController(ProductRepository repo){this.repo=repo;}

 @GetMapping public List<Product> all(@RequestParam(required=false) String category,@RequestParam(required=false) String search){
  if(search!=null && !search.isBlank()) return repo.findByNameContainingIgnoreCaseOrBrandContainingIgnoreCase(search,search);
  if(category!=null && !category.isBlank()) return repo.findByCategoryIgnoreCase(category);
  return repo.findAll();
 }
 @GetMapping("/{id}") public Product one(@PathVariable Long id){return repo.findById(id).orElseThrow();}
 @PostMapping public Product create(@Valid @RequestBody Product p){return repo.save(p);}
 @PutMapping("/{id}") public Product update(@PathVariable Long id,@Valid @RequestBody Product p){
  Product x=repo.findById(id).orElseThrow(); x.setName(p.getName());x.setCategory(p.getCategory());x.setBrand(p.getBrand());
  x.setPricePerDay(p.getPricePerDay());x.setImageUrl(p.getImageUrl());x.setDescription(p.getDescription());x.setAvailable(p.isAvailable());return repo.save(x);
 }
 @DeleteMapping("/{id}") public void delete(@PathVariable Long id){repo.deleteById(id);}
}
