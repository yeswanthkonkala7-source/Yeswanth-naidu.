package com.renttech.config;
import com.renttech.model.Product;
import com.renttech.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;

@Component
public class DataLoader implements CommandLineRunner {
 private final ProductRepository repo;
 public DataLoader(ProductRepository repo){this.repo=repo;}
 public void run(String... args){
  if(repo.count()>0)return;
  repo.save(new Product("MacBook Air M2","Laptop","Apple",new BigDecimal("899"),"https://images.unsplash.com/photo-1517336714739-489689fd1ca8?w=900","Lightweight Apple laptop for work and study."));
  repo.save(new Product("iPhone 15","Smartphone","Apple",new BigDecimal("599"),"https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?auto=format&fit=crop&w=900","Premium smartphone for short-term rental."));
  repo.save(new Product("Galaxy Tab S9","Tablet","Samsung",new BigDecimal("399"),"https://images.unsplash.com/photo-1561154464-82e9adf32764?w=900","Large-screen Android tablet."));
  repo.save(new Product("Sony A7 III","Camera","Sony",new BigDecimal("749"),"https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=900","Full-frame mirrorless camera."));
 }
}
