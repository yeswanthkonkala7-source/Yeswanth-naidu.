package com.renttech.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name="rentals")
public class Rental {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @NotBlank private String customerName;
 @Email @NotBlank private String customerEmail;
 @NotBlank private String phone;
 @ManyToOne(optional=false) private Product product;
 @NotNull private LocalDate startDate;
 @NotNull private LocalDate endDate;
 private BigDecimal totalPrice;
 private String status = "BOOKED";

 public Rental(){}
 public Long getId(){return id;} public String getCustomerName(){return customerName;} public void setCustomerName(String v){customerName=v;}
 public String getCustomerEmail(){return customerEmail;} public void setCustomerEmail(String v){customerEmail=v;}
 public String getPhone(){return phone;} public void setPhone(String v){phone=v;}
 public Product getProduct(){return product;} public void setProduct(Product v){product=v;}
 public LocalDate getStartDate(){return startDate;} public void setStartDate(LocalDate v){startDate=v;}
 public LocalDate getEndDate(){return endDate;} public void setEndDate(LocalDate v){endDate=v;}
 public BigDecimal getTotalPrice(){return totalPrice;} public void setTotalPrice(BigDecimal v){totalPrice=v;}
 public String getStatus(){return status;} public void setStatus(String v){status=v;}
}
